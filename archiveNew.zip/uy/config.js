global.owner = ['6281775096732']  
global.mods = ['6281775096732'] 
global.prems = ['6281775096732']
global.nameowner = 'ManzMd'
global.numberowner = '6281775096732'
global.mail = 'ManzMd@mail.co' 
global.gc = 'StarsX Cyber Team'
global.instagram = 'StarsX Cyber Team'
global.wm = '© ManzMdMD'
global.wait = '_*Tunggu sedang di proses...*_'
global.eror = '_*Server Error*_'
global.stiker_wait = '*⫹⫺ Stiker sedang dibuat...*'
global.packname = 'Made With'
global.author = 'Bot WhatsApp'
global.maxwarn = '2' // Peringatan maksimum
let fs = require('fs')
let chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  delete require.cache[file]
  require(file)
})
